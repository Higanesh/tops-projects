from django.contrib import admin
from shoppingApp.models import * 

# Register your models here.
