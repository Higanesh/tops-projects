from django.contrib import admin
from TODOApp.models import *
# Register your models here.
admin.site.register(todo)
